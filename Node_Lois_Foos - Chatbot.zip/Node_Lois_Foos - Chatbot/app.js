var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);
var app = express();

//https://www.jotform.com/blog/html5-filesystem-api-create-files-store-locally-using-javascript-webkit/
//CODE POUR LANCER LE CHATBOT
/*
var bot = new RiveScript();
var RiveScript = require('rivescript');
bot.loadFile(["brains/begin.rive","brains/admin.rive","brains/clients.rive"]).then(loading_done).catch(loading_error);

function loading_done(){
	console.log("Bot has finished loading !");
	bot.sortReplies();
	let username = "local-user";
	bot.reply(username,"Hello, bot!").then(function(reply){
		console.log("The bot says"+reply);
	});
}

function loading_error(error, filename, lineno){
	console.log("Error when loading files"+error);
}
*/


// Connection à MongoDB en local
mongoose.connect("mongodb://localhost:27017/ChatBot");
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

// utilisation de sessions pour suivre la connection de l'utilisateur
app.use(session({
  secret: 'treehouse loves you',
  resave: true,
  saveUninitialized: false,
  store: new MongoStore({
    mongooseConnection: db
  })
}));

// rend l'id de l'utilisateur disponible
app.use(function (req, res, next) {
  res.locals.currentUser = req.session.userId;
  next();
});

// parse incoming requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// serve static files from /public
app.use(express.static(__dirname + '/public'));

// paramètre des vues
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

// inclusion des routes
var routes = require('./routes/index');
app.use('/', routes);

// erreur 404
app.use(function(req, res, next) {
  var err = new Error('File Not Found');
  err.status = 404;
  next(err);
});

// error handler
// define as the last app.use callback
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

// lancement de l'appli sur le port 3000
app.listen(3000, function () {
  console.log('Application lancée sur le port 3000');
});
