
// fonction utilisée juste après un login réussi pour rediriger vers le profil
function loggedOut(req, res, next) {
  if (req.session && req.session.userId) {
    return res.redirect('/profile');
  }
  return next();
}

// fonction utilisée pour restreindre l'accès à certaines pages aux utilisateurs non connectés
function requiresLogin(req, res, next) {
  if (req.session && req.session.userId) { 		//si l'utilisateur est connecté
    return next();								//il accède bien à la page suivante (next)
  } else {										//sinon on renvoie une erreur
    var err = new Error('Il faut être connecté pour accéder à cette page.');
    err.status = 401;
    return next(err);
  }
}

// export des deux fonctions
module.exports.loggedOut = loggedOut;
module.exports.requiresLogin = requiresLogin;
