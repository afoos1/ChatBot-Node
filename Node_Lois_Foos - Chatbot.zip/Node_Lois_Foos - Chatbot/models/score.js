var mongoose = require('mongoose');

// définition du modèle Score
var ScoreSchema = new mongoose.Schema({
    name: {
      type: String,
      unique: false,
      required: true,
      trim: true
    },
    jeu: {
      type: String,
	  unique: false,
      required: true,
      trim: true
    },
    record: {
      type: Number,
	  unique: false,
      required: true,
      trim: true
    },
});

// exportation du modèle Score
var Score = mongoose.model('Score', ScoreSchema);
module.exports = Score;