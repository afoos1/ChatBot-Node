var mongoose = require('mongoose');
var bcrypt = require('bcryptjs'); //module de cryptage de mot de passe

// définition du modèle User
var UserSchema = new mongoose.Schema({
    email: {
      type: String,
      unique: true,
      required: true,
      trim: true
    },
    name: {
      type: String,
	  unique: true,
      required: true,
      trim: true
    },
    password: {
      type: String,
      required: true
    }
});

// Authentification, exécutée lors du login
UserSchema.statics.authenticate = function(email, password, callback) {
  User.findOne({ email: email })
      .exec(function (error, user) {
        if (error) {
          return callback(error);
        } else if ( !user ) {
          var err = new Error('User not found.');
          err.status = 401;
          return callback(err);
        }
        bcrypt.compare(password, user.password , function(error, result) {
          if (result === true) {
            return callback(null, user);
          } else {
            return callback();
          }
        })
      });
}


// hachage du mot de passe avant de le stocker en base de données
UserSchema.pre('save', function(next) {
  var user = this;
  bcrypt.hash(user.password, 10, function(err, hash) {
    if (err) {
      return next(err);
    }
    user.password = hash;
    next();
  })
});

// exportation du modèle User
var User = mongoose.model('User', UserSchema);
module.exports = User;
