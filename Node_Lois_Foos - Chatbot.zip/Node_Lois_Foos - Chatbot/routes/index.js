var express = require('express');
var router = express.Router();
var User = require('../models/user');
var Score = require('../models/score');
var mid = require('../middleware');
var RiveScript = require('rivescript');
var net = require('net');

var express = require('express');
var RiveScript = require("rivescript");



//mauvaise méthode, on doit pouvoir connaitre le statut des serveurs
//pas reussi à utiliser la méthode avec les promise
var flag1 = false;
var flag2 = false;
var flag3 = false;
var b1 = 1;
var b2 = 1;
var b3 = 1;

function loadBrain(num,brain){
	switch (num){
		case 1: bot1.loadFile(brain);
		console.log("Brain of Bot1 modfied : "+brain);
		break;
		case 2: bot2.loadFile(brain);
		console.log("Brain of Bot2 modfied : "+brain);
		break;
		case 3: bot3.loadFile(brain);
		console.log("Brain of Bot3 modfied : "+brain);
		break;
	}
}

var app1 = express();
var http1 = require('http').Server(app1);
var io1 = require('socket.io')(http1);

var bot1 = new RiveScript();

bot1.loadFile("brain/brain1.rive");

app1.use(express.static('assets'));

app1.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html');
});

function proceedMsg(name,msg){
		console.log("Fonction proceed :"+name);
		switch (msg){
		case "": bot1.loadFile(brain);
		console.log("");
		break;
		case 2: bot2.loadFile(brain);
		console.log("Brain of Bot2 modfied : "+brain);
		break;
		case 3: bot3.loadFile(brain);
		console.log("Brain of Bot3 modfied : "+brain);
		break;}
}

io1.on('connection', function (socket) {
  socket.on('chat message', function (msg) {
    bot1.sortReplies();
    // And now we're free to get a reply from the brain!
    console.log("Input received: " + msg);
	
    var reply = bot1.reply("local-user", msg);
    io1.emit('chat message', reply);
    console.log("Bot response: " + reply);
  });
});

var app2 = express();
var http2 = require('http').Server(app2);
var io2 = require('socket.io')(http2);

var bot2 = new RiveScript();

bot2.loadFile("brain/brain1.rive");

app2.use(express.static('assets'));

app2.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html');
});

io2.on('connection', function (socket) {
  socket.on('chat message', function (msg) {
    bot2.sortReplies();

    // And now we're free to get a reply from the brain!
    console.log("Input received: " + msg);
    var reply = bot2.reply("local-user", msg);
    io2.emit('chat message', reply);
    console.log("Bot response: " + reply);
  });
});

var app3 = express();
var http3 = require('http').Server(app3);
var io3 = require('socket.io')(http3);

var bot3 = new RiveScript();

bot3.loadFile("brain/brain1.rive");

app3.use(express.static('assets'));

app3.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html');
});

io3.on('connection', function (socket) {
  socket.on('chat message', function (msg) {
    bot3.sortReplies();

    // And now we're free to get a reply from the brain!
    console.log("Input received: " + msg);
    var reply = bot3.reply("local-user", msg);
    io3.emit('chat message', reply);
    console.log("Bot response: " + reply);
  });
});

router.get('/erreur', mid.requiresLogin, function(req, res, next) {
  return res.render('erreur', { title: 'Erreur'});
});

router.get('/botmod',mid.requiresLogin, function(req,res,next){
	return res.render('botmod', {title: 'Associer des cerveux et des bots',v1: b1,v2: b2,v3: b3});
});

router.get('/bot/:id', mid.requiresLogin, function(req,res,next){
	var num = req.params.id;

	if (num==1){res.writeHead(302, {
    Location: 'http://localhost:3001'
});
}
		if (num==2){res.writeHead(302, {
    Location: 'http://localhost:3002'
});
}
		if (num==3){res.writeHead(302, {
    Location: 'http://localhost:3003'
});
	}
	res.end();
});

// GET /login
router.get('/botadd', mid.requiresLogin, function(req, res, next) {
  return res.render('botadd', { title: 'Mise en ligne des bot',f1: flag1, f2: flag2, f3: flag3});
});

router.get('/botmodfin/:code',mid.requiresLogin, function(req,res,next){
	var x = req.params.code;
	
	bot1 = new RiveScript();
	var path = 'brain/brain'+parseInt(x/100)+'.rive';
	b1 = parseInt(x/100);
	loadBrain(1,path);
	x=x-parseInt(x/100)*100;
	http1.close();
	if (flag1){http1.listen(3001);}
	
	bot2 = new RiveScript();
	path = 'brain/brain'+parseInt(x/10)+'.rive';
	b2 = parseInt(x/10);
	loadBrain(2,path);
	x=x-parseInt(x/10)*10;
	http2.close();
	if (flag2){http2.listen(3002);}
	
	bot3 = new RiveScript();
	path = 'brain/brain'+parseInt(x)+'.rive';
	b3 = parseInt(x);
	loadBrain(3,path);
	http3.close();
	if (flag3){http3.listen(3003);}
	
	return res.render('botaddfin', { title: 'Opération terminée'});
	
});

router.get('/botaddfin/:code', mid.requiresLogin, function(req, res, next) {
	var x = req.params.code;
	if (parseInt(x/100)==1){ // JR duid vhztbot 3
	
	

		x=x-100;
		http3.close();
http3.listen(3003, function () {
  console.log('Started listening on *:3003');
  flag3 =true;
});
	}else{
		http3.close();
		console.log('Port 3003 fermé');
		flag3 =false;
		
	}
	if (parseInt(x/10)==1){ // 2
		x=x-10;
		http2.close();
				http2.listen(3002, function () {
  console.log('Started listening on *:3002');
  flag2 = true;
				});
	}else{
				http2.close();
		console.log('Port 3002 fermé');
		flag2 = false;
	}
	if (x==1){ // 1
		http1.close();
		http1.listen(3001, function () {
  console.log('Started listening on *:3001');
  flag1 = true;
		});
	}else{
		http1.close();
		console.log('Port 3001 fermé');
		flag1 = false;
	}

		
  return res.render('botaddfin', { title: 'Opération terminée'});
});


// GET /login
router.get('/botvalider/:id', mid.requiresLogin, function(req, res, next) {
  return res.render('botadd', { title: 'Mise en ligne des bot'});
});

router.get('/gentil/:nom', mid.requiresLogin, function(req, res, next){
	// create object with form input
	//User.findById(req.session.userId)
	User.findById(req.session.userId)
      .exec(function (error, user) {
		  var bot = new RiveScript();

bot.loadFile(["brains/begin.rive","brains/admin.rive","brains/clients.rive"]).then(loading_done).catch(loading_error);

function loading_done(){
	console.log("Bot has finished loading !");
	bot.sortReplies();
	let username = "local-user";
	bot.reply(username,"Hello, bot!").then(function(reply){
		console.log("The bot says"+reply);
	});
}



function loading_error(error, filename, lineno){
	console.log("Error when loading files"+error);
}
        if (error) {
          return next(error);
        } else {
          var pseudo = user.name;
		  Score.find({"name":pseudo,"jeu":"Casse-Brique"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		return res.render('gentil', {items : doc})
		});
        }
	  });
});

router.get('/mechant/:nom', mid.requiresLogin, function(req, res, next){
	// create object with form input
	//User.findById(req.session.userId)
	User.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          var pseudo = user.name;
		  Score.find({"name":pseudo,"jeu":"Casse-Brique"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		return res.render('mechant', {items : doc})
		});
        }
	  });
});

// GET /login
router.get('/adminbot', mid.requiresLogin, function(req, res, next) {
  return res.render('adminbot', { title: 'AdminBot'});
});

// GET /profile
router.get('/profile', mid.requiresLogin, function(req, res, next) {
  User.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          return res.render('profile', { title: 'Profile', name: user.name, email: user.email, ident : user._id});
        }
      });
});


router.get('/contact', mid.requiresLogin, function(req, res, next) {
	Score.find({"jeu":"Flappy Bird"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		res.render('contact', {items : doc})
		});
});

router.get('/contact2', mid.requiresLogin, function(req, res, next) {
	Score.find({"jeu":"Casse-Brique"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		res.render('contact2', {items : doc})
		});
});

// GET /jeu
router.get('/jeu_bird', function(req, res, next){
	return res.render('jeu_bird', {title : 'titre' });
});

// GET /jeu
router.get('/jeu_brique', function(req, res, next){
	return res.render('jeu_brique', {title : 'Casse-Brique' });
});

// GET /fin
router.get('/fin_bird/:id', mid.requiresLogin, function(req, res, next){
	User.findById(req.session.userId)
	.then(function(user){
	
			var newScore = {
				name: user.name,
				jeu: 'Flappy Bird',
				record: req.params.id,
			}
			

			Score.create(newScore, function (error, user) {
				if (error) {
					return next(error);
				} else {
					return res.render('fin_bird', {title : 'titre' , output: req.params.id});
				}
			});
	});
});

// GET /fin2
router.get('/fin_brique/:id', mid.requiresLogin, function(req, res, next){
	User.findById(req.session.userId)
	.then(function(user){
	
			var newScore = {
				name: user.name,
				jeu: 'Casse-Brique',
				record: req.params.id,
			}
			

			Score.create(newScore, function (error, user) {
				if (error) {
					return next(error);
				} else {
					return res.render('fin_brique', {title : 'titre' , output: req.params.id});
				}
			});
	});
});



// GET /pagetest
router.get('/pagetest', mid.requiresLogin, function(req, res, next){
	// create object with form input
	//User.findById(req.session.userId)
	Score.find({})
		.then(function(doc){
		res.render('pagetest', {items : doc})
		});
});

// GET /pagetest
router.get('/tableau_bird/:nom', mid.requiresLogin, function(req, res, next){
	// create object with form input
	//User.findById(req.session.userId)
	User.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          var pseudo = user.name;
		  Score.find({"name":pseudo,"jeu":"Flappy Bird"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		return res.render('tableau_bird', {items : doc})
		});
        }
	  });
});

// GET /pagetest
router.get('/tableau_brique/:nom', mid.requiresLogin, function(req, res, next){
	// create object with form input
	//User.findById(req.session.userId)
	User.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          var pseudo = user.name;
		  Score.find({"name":pseudo,"jeu":"Casse-Brique"},{"_id":0,"__v":0,"jeu":0}).sort( { record: -1 } )
		.then(function(doc){
		return res.render('tableau_brique', {items : doc})
		});
        }
	  });
});
	
	
	/*Score.find({"name":"abc"})
	.exec(function (error, score) {
		if (error){
			return next(error);
		}else{
	
			var newScore = {
				name: user.name,
				jeu: 'Flappy Bird',
				record: 10,
				
			};

			// use schema's `create` method to insert document into Mongo
			Score.create(newScore, function (error, user) {
				if (error) {
					return next(error);
				} else {
					return res.render('pagetest', {title : 'test', valeur : score.name });
				}
			});
		}
});
});*/


// GET /logout
router.get('/logout', function(req, res, next) {
  if (req.session) {
    // delete session object
    req.session.destroy(function(err) {         //destruction de la session user
      if(err) {
        return next(err);
      } else {
        return res.redirect('/');
      }
    });
  }
});

// GET /login
router.get('/login', mid.loggedOut, function(req, res, next) {
  return res.render('login', { title: 'Log In'});
});

// POST /login
router.post('/login', function(req, res, next) {
  if (req.body.email && req.body.password) {
    User.authenticate(req.body.email, req.body.password, function (error, user) {
      if (error || !user) {
        var err = new Error('Wrong email or password.');
        err.status = 401;
        return next(err);
      }  else {
        req.session.userId = user._id;      //creation de la session user en cours ====================================================
        return res.redirect('/profile');
      }
    });
  } else {
    var err = new Error('Email and password are required.');
    err.status = 401;
    return next(err);
  }
});

// GET /admin
router.get('/admin', function(req, res, next) {
	User.find({},{"_id":0,"email":0,"password":0,"__v":0})
		.then(function(doc){
	return res.render('admin', { title: 'Admin',utilisateurs : doc});
  });
});

// POST /admin
router.post('/admin', function(req, res, next) {
  if (req.body.pseudo) {


	var newName = {
		name: req.body.pseudo,
	}

	Score.deleteMany(newName, function (error){});
	User.deleteOne(newName, function (error) {
		if (error) {
			return next(error);
		} else {
			return res.render('admin_fin');
		}
	});
 
}
});

// POST /admin
/*router.post('admin', function(req, res, next) {
	if (req.body.pseudo){
		var data = {name :req.body.pseudo};
		User.deleteOne(data, function(error, user) {
			if (error) {
				return next(error);
			} else {
				return res.redirect('/admin');
			}
		});
	}
});*/

router.get('/admin_fin', mid.requiresLogin, function(req, res, next){
	return res.render('/admin_fin', {title : 'titre'});
});


// GET /register
router.get('/register', mid.loggedOut, function(req, res, next) {
  return res.render('register', { title: 'Sign Up' });
});

// POST /register
router.post('/register', function(req, res, next) {
  if (req.body.email &&
    req.body.name &&
    req.body.password &&
    req.body.confirmPassword) {

      // confirm that user typed same password twice
      if (req.body.password !== req.body.confirmPassword) {
        var err = new Error('Passwords do not match.');
        err.status = 400;
        return next(err);
      }

      // create object with form input
      var userData = {
        email: req.body.email,
        name: req.body.name,
        password: req.body.password
      };

      // use schema's `create` method to insert document into Mongo
      User.create(userData, function (error, user) {
        if (error) {
          return next(error);
        } else {
          req.session.userId = user._id;
          return res.redirect('/profile');
        }
      });

    } else {
      var err = new Error('All fields required.');
      err.status = 400;
      return next(err);
    }
})

// GET /
router.get('/', function(req, res, next) {
  return res.render('index', { title: 'Home' });
});

// GET /chatbot
router.get('/chatbot',mid.requiresLogin, function(req, res, next) {
    User.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          return res.render('chatbot', { title: 'Chatbot', name: user.name, f1: flag1, f2: flag2, f3: flag3});
        }
      });
});


// GET /about
router.get('/about', function(req, res, next) {
  return res.render('about', { title: 'About' });
});


module.exports = router;
